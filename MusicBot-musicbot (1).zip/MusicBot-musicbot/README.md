# Telegram Song Download Bot ❤

## You can download any song using this bot. Can be found in telegram as [@JESongBot](https://t.me/JESongBot)

### Commands:
- In Groups - `/song <song name>`
- In Private - Just send song name

### Deploy to Heroku 🏃‍♂

[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/ImJanindu/Songdl-tgbot)

### Credits:

- [Infinity BOTs](https://t.me/Infinity_BOTs)

- [Pyrogram Library](https://github.com/pyrogram/pyrogram)

### Developers:

- [@ImJanindu](https://t.me/ImJanindu)

- [@InukaASiTH](https://t.me/InukaASiTH)
